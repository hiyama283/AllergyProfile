package gson;

public class UserTest {
    public String email;
    public String fullName;

    public UserTest(String email, String fullName) {
        this.email = email;
        this.fullName = fullName;
    }
}
