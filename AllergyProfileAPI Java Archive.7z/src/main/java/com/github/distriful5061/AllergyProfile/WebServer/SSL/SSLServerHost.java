package com.github.distriful5061.AllergyProfile.WebServer.SSL;

public class SSLServerHost {
}
