/**
 * APIのサーバーとして動くクラスをまとめたパッケージ。この下に更にパッケージが枝分かれする
 *
 * @since 1.0
 */
package com.github.distriful5061.AllergyProfile.WebServer;