/**
 * ハンドラーパッケージ。基本的にWeb系のハンドラーを配置する。この下にメソッドごとに分割したパッケージを配置する
 *
 * @since 1.1
 */
package com.github.distriful5061.AllergyProfile.Handlers.WebHandlers;