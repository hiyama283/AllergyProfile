/**
 * HTTP通信を行うためのクラスをまとめたパッケージ。SSLは別のパッケージです。Utilsとして作用させているファイルは、最後にUtilsとつけてUtilsパッケージに移動させるべきです
 *
 * @since 1.0
 */
package com.github.distriful5061.AllergyProfile.WebServer.Http;