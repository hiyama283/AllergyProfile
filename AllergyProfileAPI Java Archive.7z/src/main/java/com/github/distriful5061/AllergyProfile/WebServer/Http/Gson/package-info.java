/**
 * Gsonに通すためのクラスを管理するためのパッケージ。情報間利用クラスだけ入れるように！！！
 *
 * @since 1.1
 */
package com.github.distriful5061.AllergyProfile.WebServer.Http.Gson;