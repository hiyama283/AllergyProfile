package com.github.distriful5061.AllergyProfile.mixins.gson;

public class ApiConfig {
    public int port;

    public ApiConfig(int port) {
        this.port = port;
    }
}
