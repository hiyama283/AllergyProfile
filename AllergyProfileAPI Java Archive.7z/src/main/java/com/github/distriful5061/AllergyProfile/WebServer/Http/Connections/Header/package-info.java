/**
 * ヘッダー情報それ自体を表すクラス。全体ではなく、一つの情報に注目して表しています。基本的にenumを使用するべきです。
 *
 * @since 1.1
 */
package com.github.distriful5061.AllergyProfile.WebServer.Http.Connections.Header;