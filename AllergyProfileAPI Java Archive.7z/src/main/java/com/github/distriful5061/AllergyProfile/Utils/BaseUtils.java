package com.github.distriful5061.AllergyProfile.Utils;

/**
 * Utilsファイルを作る際に必須となる機能を抽象化したinterface。
 *
 * @since 1.0.0
 */
public interface BaseUtils {
    int hashCode();
}
