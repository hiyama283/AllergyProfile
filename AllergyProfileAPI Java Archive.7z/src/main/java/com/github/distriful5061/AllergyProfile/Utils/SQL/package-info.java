/**
 * SQLへ接続したり、SQLの操作を行うクラスをまとめたパッケージ。SQL操作に関係ないならば、他の名称のpackageを追加するべき。
 *
 * @since 1.0
 */
package com.github.distriful5061.AllergyProfile.Utils.SQL;