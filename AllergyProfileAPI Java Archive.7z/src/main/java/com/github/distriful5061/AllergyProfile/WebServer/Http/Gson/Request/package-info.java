/**
 * リクエストとしてきたJsonを解析するためのクラスをまとめるためのパッケージ
 *
 * @since 1.1
 */
package com.github.distriful5061.AllergyProfile.WebServer.Http.Gson.Request;