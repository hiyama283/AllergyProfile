/**
 * 接続や送信されたデータを表すクラスをまとめたパッケージ。enumなどは他のパッケージにまとめるか、最後にenumをつけるかして分類してください。また、情報を表すクラスのみをここにまとめてください。もし動的に処理するような物があるならば。ひとつ上のパッケージにまとめるべきです。
 *
 * @since 1.1
 */
package com.github.distriful5061.AllergyProfile.WebServer.Http.Connections;