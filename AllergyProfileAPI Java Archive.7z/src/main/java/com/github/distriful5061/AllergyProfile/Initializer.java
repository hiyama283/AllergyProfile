package com.github.distriful5061.AllergyProfile;

import com.github.distriful5061.AllergyProfile.Utils.Log.LogUtils;

import com.github.distriful5061.AllergyProfile.WebServer.Http.HttpServerHost;
import com.github.distriful5061.AllergyProfile.mixins.gson.ConfigJson;
import com.github.distriful5061.AllergyProfile.mixins.MixinLoadConfig;
import com.github.distriful5061.AllergyProfile.mixins.MixinLoadUtils;
import com.github.distriful5061.AllergyProfile.mixins.MixinSetHandlers;
import com.github.distriful5061.cryptlibrary.NewPassWord;


public class Initializer {
    public static ConfigJson config;
    public static void main(String[] args) {
        // Mixin
        LogUtils.println("Mixin Started");
        MixinLoadConfig.main();

        MixinLoadUtils.main();
        MixinSetHandlers.main();

        // Random Seed
        if (config.regenRandomSeed) {
            NewPassWord newPassWord = new NewPassWord();
            long seed = System.nanoTime();

            for (int i = 1; i <= 100; i++) {
                long newSeed = newPassWord.getRandomMaxLong(seed);
                config.randomSeedList.add(newSeed);
                seed = seed ^ newSeed;
            }

            config.regenRandomSeed = false;

            MixinLoadConfig.saveConfig();
        }

        // Start Server
        LogUtils.println("Main Server Thread booted");
        HttpServerHost httpServerHost = new HttpServerHost(config.getHttpApiConfig().port);
        new Thread(httpServerHost).start();
    }
}
