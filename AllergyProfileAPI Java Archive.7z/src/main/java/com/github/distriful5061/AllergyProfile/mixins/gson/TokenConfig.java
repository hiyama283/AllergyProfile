package com.github.distriful5061.AllergyProfile.mixins.gson;

public class TokenConfig {
}
