/**
 * Json関連(自作)をまとめたパッケージ。Gson仕様に伴い廃止
 *
 * @since 1.0
 */
package com.github.distriful5061.AllergyProfile.Json;