package com.github.distriful5061.AllergyProfile.Utils.SQL;

/**
 * SQLUtils.javaと連携し、コラムとして機能するクラス。現在、型問題の解決ができなかったため、一時的なキャッシュ方式に切替。
 *
 * @since 1.0.0
 */
@Deprecated
public class Column {
    @Override
    public int hashCode() {
        return 0;
    }
}
