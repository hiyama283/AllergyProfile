/**
 * Webパッケージとして処理する際に起動されるException
 *
 * @since 1.0
 */
package com.github.distriful5061.AllergyProfile.WebServer.Http.Exception;