/**
 * Log4jを習って実装したLogのUtilsパッケージ。ファイルにログを出力したりする際に、これをいじるだけでいいのでとても楽
 *
 * @since 1.1
 */
package com.github.distriful5061.AllergyProfile.Utils.Log;