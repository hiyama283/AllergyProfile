/**
 * GETメソッドに関連つけられているハンドラーをまとめたパッケージ。Mixinでハンドラーに設定する必要がある
 *
 * @since 1.1
 * @see com.github.distriful5061.AllergyProfile.mixins.MixinSetHandlers
 */
package com.github.distriful5061.AllergyProfile.Handlers.WebHandlers.GET;