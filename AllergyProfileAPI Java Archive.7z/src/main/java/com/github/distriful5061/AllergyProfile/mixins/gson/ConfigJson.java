package com.github.distriful5061.AllergyProfile.mixins.gson;

import java.util.List;

public class ConfigJson {
    public boolean regenRandomSeed;
    public ApiConfig httpApiConfig;
    public TokenConfig tokenAuthConfig;
    public List<Long> randomSeedList;

    public ConfigJson(boolean regenerateRandomSeed, ApiConfig apiConfig, TokenConfig tokenConfig, List<Long> seedList) {
        this.regenRandomSeed = regenerateRandomSeed;
        this.httpApiConfig = apiConfig;
        this.tokenAuthConfig = tokenConfig;
        this.randomSeedList = seedList;
    }

    public ApiConfig getHttpApiConfig() {
        return this.httpApiConfig;
    }

    public TokenConfig getTokenAuthConfig() {
        return this.tokenAuthConfig;
    }
}
