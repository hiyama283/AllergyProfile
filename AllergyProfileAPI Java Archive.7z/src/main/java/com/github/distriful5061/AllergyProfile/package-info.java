/**
 * ルートパッケージ。ここにすべてを管理するようなJavaファイルや、分類ができない(コアファイルなど)ファイルを配置する。この下にパッケージを追加していく
 *
 * @since 1.0
 */
package com.github.distriful5061.AllergyProfile;