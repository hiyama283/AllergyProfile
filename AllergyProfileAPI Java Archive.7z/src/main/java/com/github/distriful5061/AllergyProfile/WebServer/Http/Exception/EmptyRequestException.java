package com.github.distriful5061.AllergyProfile.WebServer.Http.Exception;

import java.io.Serial;

public class EmptyRequestException extends RuntimeException {
    @Serial
    private static final long serialVersionUID = 1L;
}
